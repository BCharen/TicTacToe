package ticTacToe;


//after work on checkers
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
public class TicTacToeMain {

	static String curPlayer = "X";
	public static void main(String[] args) {
		
		String[][] grid = new String[3][3];
		
		for(int i = 0; i < grid.length; i++) {
			for(int j = 0; j < grid[0].length;j++) {
				grid[i][j] = " ";
			}
		}
		
		JFrame frame = new JFrame();
		JButton[][] frameGrid = new JButton[3][3];
		final int frameSize = 900;
		frame.setSize(frameSize, frameSize);
		for (int i = 0; i < frameGrid.length; i++) {
			for (int j = 0; j < frameGrid.length; j++) {
			frameGrid[i][j] = new JButton("");
			frameGrid[i][j].setFont(new Font("Arial", Font.PLAIN, 40));
			frameGrid[i][j].addActionListener(new ActionListener(){
	             public void actionPerformed(ActionEvent event){
	            	 for (int testI = 0; testI < frameGrid.length; testI++){
	            	        for (int testJ= 0; testJ < frameGrid[testI].length; testJ++){
	            	            if (event.getSource() == frameGrid[testI][testJ]){
	            	                buttonPressed(testI,testJ,grid,getCurPlayer(),frameGrid[testI][testJ]);
	            	            }                                       
	            	        }
	            	 }
	             }
	       });
				
			frame.add(frameGrid[i][j]);
			
			}
		}
		frame.setLayout(new GridLayout(3,3));
		frame.setVisible(true);
		
		
			
			
		

	}
	
	private static String swapPlayer(String curPlayer) {
		if(curPlayer == "X") {
			return "O";
		}
		else {
			return "X";
		}
	}
	private static String getCurPlayer() {
		return curPlayer;
	}
	private static void setCurPlayer(String setter) {
		curPlayer = setter;
	}
	
	
	public static boolean checkMove(int verticalCoordinate, int horizontalCoordinate, String grid[][]) {


			if (grid[verticalCoordinate][horizontalCoordinate] == " ") {
				return true;
			}
		
		
		return false;
	}
	
	public static boolean checkWin(int verticalCoordinate, int horizontalCoordinate, String curPlayer,String grid[][]) {
		boolean win = false;
		for (int i = 0; i < grid.length; i++) {
			if(!curPlayer.equals(grid[i][horizontalCoordinate])) {
				break;
			}
			if (i == grid.length-1) {
				win = true;
			}
		}
		for (int i = 0; i < grid.length && win == false; i++) {
			if(!curPlayer.equals(grid[verticalCoordinate][i])) {
				break;
			}
			if (i == grid.length-1) {
				win = true;
			}
		}
		for (int i = 0; i < grid.length && win == false; i++) {
			if(!curPlayer.equals(grid[i][i])) {
				break;
			}
			if (i == grid.length-1) {
				win = true;
			}
		}
		for (int i = 0; i < grid.length && win == false; i++) {
			if(!curPlayer.equals(grid[grid.length-1-i][i])) {
				break;
			}
			if (i == grid.length-1) {
				win = true;
			}
		}
		return win;
	}
	
	public static void buttonPressed(int verticalCoordinate, int horizontalCoordinate, String grid[][], String curPlayer, JButton button) {
			
		try {
			if(checkMove(verticalCoordinate, horizontalCoordinate, grid)) {
				grid[verticalCoordinate][horizontalCoordinate] = curPlayer;
			}
			else {
				throw new Exception();
			}
			if (checkWin(verticalCoordinate, horizontalCoordinate, curPlayer, grid)) {
				printWin(curPlayer);
			}
			setCurPlayer(swapPlayer(curPlayer));
			button.setText(curPlayer);
		}
		catch(Exception e) {
			
		}
			
		
	}
	public static void printWin(String curPlayer) {
		JOptionPane.showMessageDialog(null,curPlayer + " Wins!",curPlayer + " Wins!",JOptionPane.DEFAULT_OPTION);
		System.exit(0);
	}
	
}
